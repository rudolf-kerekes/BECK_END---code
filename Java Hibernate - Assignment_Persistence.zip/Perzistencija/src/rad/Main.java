package rad;

import com.mysql.jdbc.*;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.*;
import javax.swing.JOptionPane;

public class Main {
    public static void main(String[] args) {
       
        
        String posao=JOptionPane.showInputDialog("Unesite jednu od operacija(dodaj, prikaziSve, uslovnoBrisanje, prikazZaposlenihUslovno, izmeniPodatak):");
        
        switch(posao){
            case "dodaj":
                dodaj();
                System.out.println("dodaj");
                break;
            case "prikaziSve":
                System.out.println("prikaziSve");
                prikaziSve();
                break;
            case "uslovnoBrisanje":
                uslovnoBrisanje();
                System.out.println("uslovnoBrisanje");
                break;
            case "prikazZaposlenihUslovno":
                prikazZaposlenihUslovno();
                System.out.println("prikazZaposlenihUslovno");
                break;
            case "izmeniPodatak":
                izmeniPodatak();
                System.out.println("izmeniPodatak");
                break;
            default:
                System.out.println("Pogresan unos.");
        }
        
    }
    
    public static void dodaj(){
        try(java.sql.Connection conn= DriverManager.getConnection("jdbc:mysql://localhost/zaposleni", "root", "PASS")){
            System.out.println("Konekcija:"+conn.isClosed());
            
            String ime=JOptionPane.showInputDialog("Unesite ime: ");
            int god=Integer.parseInt(JOptionPane.showInputDialog("Unesite godine: "));
            String adres=JOptionPane.showInputDialog("Unesite adresu: ");
            double dohodak=Double.parseDouble(JOptionPane.showInputDialog("Unesite dohodak: "));
            
            Radnici radnici=new Radnici(ime, god, adres, dohodak);
            
            //UNOS ZAPOSLENIH
            java.sql.PreparedStatement ps=conn.prepareStatement("insert into radnici(ime,broj_godina,adresa,visina_dohodka) values(?,?,?,?);");
            ps.setString(1, radnici.getIme());
            ps.setInt(2, radnici.getBrGodina());
            ps.setString(3, radnici.getAdresa());
            ps.setDouble(4, radnici.getVisinaDohodka());
            ps.execute();
            
        }catch(Exception exc){
            JOptionPane.showMessageDialog(null, "Greska u dodavanju:"+exc.getMessage());
        }
    }
    
    public static void prikaziSve(){
        try(java.sql.Connection conn= DriverManager.getConnection("jdbc:mysql://localhost/zaposleni", "root", "PASS")){
            
            //PRIKAZ SVIH ZAPOSLENIH
            Radnici rad=null;
            List<Radnici> kolekcija_radnika=new ArrayList();
            
            java.sql.Statement st=conn.createStatement();
            st.executeQuery("select * from radnici");
            ResultSet rs=st.getResultSet();
            while(rs.next()){
                rad=new Radnici(rs.getString("ime"),rs.getInt("broj_godina"),rs.getString("adresa"), rs.getDouble("visina_dohodka"));
                kolekcija_radnika.add(rad);
            }
            for(Radnici k: kolekcija_radnika){
                System.out.println(k.getIme()+" "+k.getBrGodina()+" " +k.getAdresa()+" " +k.getVisinaDohodka());
            }
            
        }catch(Exception exc){
            JOptionPane.showMessageDialog(null, "Greska u izlistavanju podataka:"+exc.getMessage());
        }
    }
    
    public static void uslovnoBrisanje(){
        try(java.sql.Connection conn= DriverManager.getConnection("jdbc:mysql://localhost/zaposleni", "root", "PASS")){
            
            Radnici rad=null;
            List<Radnici> kolekcija_radnika=new ArrayList();
            
            java.sql.Statement st=conn.createStatement();
            st.executeQuery("select * from radnici");
            ResultSet rs=st.getResultSet();
            while(rs.next()){
                rad=new Radnici(rs.getString("ime"),rs.getInt("broj_godina"),rs.getString("adresa"), rs.getDouble("visina_dohodka"));
                kolekcija_radnika.add(rad);
            }
            for(Radnici k: kolekcija_radnika){                
                //USLOVNO ZA BRISANJE - AKO JE DOHODAK MANJI OD 0
                if(k.getVisinaDohodka()<0){
                    st.execute("DELETE FROM radnici WHERE ime='"+k.getIme()+"'");
                    continue;
                }
                System.out.println(k.getIme()+" "+k.getBrGodina()+" " +k.getAdresa()+" " +k.getVisinaDohodka());
            }
            
        }catch(Exception exc){
            JOptionPane.showMessageDialog(null, "Greska pri uslovnom brisanju podataka:"+exc.getMessage());
        }
    }
    
    public static void prikazZaposlenihUslovno(){
        try(java.sql.Connection conn= DriverManager.getConnection("jdbc:mysql://localhost/zaposleni", "root", "PASS")){
            
            //PRIKAZ SVIH ZAPOSLENIH PO KRITERIJUMU VISINE DOHODKA(<3000)
            double dohodak=Double.parseDouble(JOptionPane.showInputDialog("Unesite gornju granicu dohodka za pretragu: "));
            
            System.out.println();
            System.out.println("PRIKAZ SVIH ZAPOSLENIH PO KRITERIJUMU VISINE DOHODKA(<"+dohodak+")");
            Radnici radd=null;
            List<Radnici> kolekcija_krit_radnika=new ArrayList();
            java.sql.Statement stt=conn.createStatement();
            stt.executeQuery("SELECT * FROM zaposleni.radnici WHERE visina_dohodka<"+dohodak+";");
            ResultSet rss=stt.getResultSet();
            while(rss.next()){
                radd=new Radnici(rss.getString("ime"),rss.getInt("broj_godina"),rss.getString("adresa"), rss.getDouble("visina_dohodka"));
                kolekcija_krit_radnika.add(radd);
            }
            for(Radnici k: kolekcija_krit_radnika){
                System.out.println(k.getIme()+" "+k.getBrGodina()+" " +k.getAdresa()+" " +k.getVisinaDohodka());
            }
            
        }catch(Exception exc){
            JOptionPane.showMessageDialog(null, "Greska pri uslovnom prikazivanju podataka:"+exc.getMessage());
        }
    }
    
    public static void izmeniPodatak(){
        try(java.sql.Connection conn= DriverManager.getConnection("jdbc:mysql://localhost/zaposleni", "root", "PASS")){
            System.out.println(conn.isClosed());
            int idIzmena=Integer.parseInt(JOptionPane.showInputDialog("Unesite id: "));
            
            java.sql.Statement sttt=conn.createStatement();
            
            String odabir=JOptionPane.showInputDialog("Sta treba menjati(ime,adresa,godine,dohodak): ");
            
            switch(odabir){
                case "ime":
                    String imee=JOptionPane.showInputDialog("Unesi novo ime:");
                    sttt.execute("UPDATE radnici SET `ime`='"+imee+"' WHERE radnici_id="+idIzmena+";");
                    break;
                case "adresa":
                    String adres=JOptionPane.showInputDialog("Unesi novu adresu:");
                    sttt.execute("UPDATE radnici SET `adresa`='"+adres+"' WHERE radnici_id="+idIzmena+";");
                    break;
                case "godine":
                    String god=JOptionPane.showInputDialog("Unesi nove godine:");
                    sttt.execute("UPDATE radnici SET `broj_godina`='"+god+"' WHERE radnici_id="+idIzmena+";");
                    break;
                case "dohodak":
                    double vred=Double.parseDouble(JOptionPane.showInputDialog("Unesi novu vrednost dohodka:"));
                    sttt.execute("UPDATE radnici SET visina_dohodka="+vred+" WHERE radnici_id="+idIzmena+";");
                    break;
                default:
                    System.out.println("GRESKA!!!");
            }
            
            //IZMENA PODATAKA NA OSNOVU KRITERIJUMA- radnici_id=4
            /*double vred=Double.parseDouble("Unesi novu vrednost dohodka:");
            sttt.execute("UPDATE radnici SET visina_dohodka="+vred+" WHERE radnici_id="+idIzmena);*/
            
        }catch(Exception exc){
            JOptionPane.showMessageDialog(null, "Greska pri izmeni podataka:"+exc.getMessage());
        }
    }
    
}

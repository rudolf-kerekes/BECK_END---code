package rad;

import java.io.*;

public class Radnici implements Serializable{
    
    private String ime;
    private int brGodina;
    private String adresa;
    private double visinaDohodka;

    public void setIme(String ime) {
        this.ime = ime;
    }

    public void setAdresa(String adresa) {
        this.adresa = adresa;
    }

    public void setBrGodina(int brGodina) {
        this.brGodina = brGodina;
    }

    public void setVisinaDohodka(double visinaDohodka) {
        this.visinaDohodka = visinaDohodka;
    }

    public String getAdresa() {
        return adresa;
    }

    public int getBrGodina() {
        return brGodina;
    }

    public String getIme() {
        return ime;
    }

    public double getVisinaDohodka() {
        return visinaDohodka;
    }

    @Override
    public String toString() {
        return super.toString(); //To change body of generated methods, choose Tools | Templates.
    }
    
    public Radnici(String ime,int brGodina, String adresa, double visinaDohodka){
        this.ime=ime;
        this.brGodina=brGodina;
        this.adresa=adresa;
        this.visinaDohodka=visinaDohodka;
    }
    public Radnici(){
        
    }
    
}

package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.validation.constraints.*;
import org.hibernate.validator.constraints.NotEmpty;

public class ProdajaModel {
    @NotEmpty
    private int idKupac;
    @NotEmpty
    private int idProizvod;
    private String id;

    public void setIdKupac(int idKupac) {
        this.idKupac = idKupac;
    }

    public void setIdProizvod(int idProizvod) {
        this.idProizvod = idProizvod;
    }

    public int getIdKupac() {
        return idKupac;
    }

    public int getIdProizvod() {
        return idProizvod;
    }
    
    
    //prodaja proizvoda
    public void prodajaProizvoda() throws ClassNotFoundException{
        Class.forName("com.mysql.jdbc.Driver");
        try(Connection conn=DriverManager.getConnection("jdbc:mysql://localhost/prodavnica", "root", "unesite lozinku")){
            
            
                Statement st=conn.createStatement();
                st.execute("INSERT INTO `prodavnica`.`kupuju` (`kupciID`, `proizvoidID`) VALUES ('"+idKupac+"', '"+idProizvod+"');");
                      
            
        }catch(Exception exc){
            System.out.println("Greska u konekciji 1");
            JOptionPane.showMessageDialog(null, "Morate ispuniti sva polja!");
        }
    }
    
    //spisak kupljenih stvari
    public String spisakKupljenihProizvoda() throws ClassNotFoundException{
        Class.forName("com.mysql.jdbc.Driver");
        
        StringBuilder sb=new StringBuilder();
        try(Connection conn=DriverManager.getConnection("jdbc:mysql://localhost/prodavnica", "root", "unesite lozinku")){
                
                
                
                Statement st=conn.createStatement();
                st.execute("select proizvodi.Naziv from proizvodi join kupci ON kupciID="+idKupac+"");
                ResultSet rs=st.getResultSet();
                
                while(rs.next()){
                    sb.append("Poslednje kupljeno: "+rs.getString("Naziv"));
                }
            
        }catch(Exception exc){
            System.out.println("Greska u konekciji 1");
            JOptionPane.showMessageDialog(null, "Morate ispuniti sva polja!");
        }
        
        return sb.toString();
    }
    
    
}

package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.*;
import javax.swing.JOptionPane;
import org.hibernate.validator.constraints.*;

public class KupciModel {
    @NotEmpty
    private int idKupca;
    @NotEmpty
    private String imeIPrezimeKupca;
    @NotEmpty
    private String brTelKupca;

    public void setIdKupca(int idKupca) {
        this.idKupca = idKupca;
    }

    public void setImeIPrezimeKupca(String imeIPrezimeKupca) {
        this.imeIPrezimeKupca = imeIPrezimeKupca;
    }

    public void setBrTelKupca(String brTelKupca) {
        this.brTelKupca = brTelKupca;
    }

    public int getIdKupca() {
        return idKupca;
    }

    public String getImeIPrezimeKupca() {
        return imeIPrezimeKupca;
    }

    public String getBrTelKupca() {
        return brTelKupca;
    }
    
    //unos kupaca
    public void unosKupaca() throws ClassNotFoundException{
        Class.forName("com.mysql.jdbc.Driver");
        try(Connection conn=DriverManager.getConnection("jdbc:mysql://localhost/prodavnica", "root", "unesite lozinku")){
            
            if(imeIPrezimeKupca !=null && (!imeIPrezimeKupca.isEmpty())){
                Statement st=conn.createStatement();
                st.execute("INSERT INTO `prodavnica`.`kupci` (`imeIprezime`, `BrTelefona`) VALUES ('"+imeIPrezimeKupca+"', '"+brTelKupca+"')");
            }            
            
        }catch(Exception exc){
            System.out.println("Greska u konekciji 1");
            JOptionPane.showMessageDialog(null, "Morate ispuniti sva polja!");
        }
    }
    
    //brisanje kupaca
    public void brisanjeKupca() throws ClassNotFoundException{
        Class.forName("com.mysql.jdbc.Driver");
        try(Connection conn=DriverManager.getConnection("jdbc:mysql://localhost/prodavnica", "root", "unesite lozinku")){
            
            
                Statement st=conn.createStatement();
                st.execute("DELETE FROM `prodavnica`.`kupci` WHERE `kupciID`='"+idKupca+"'");
                        
            
        }catch(Exception exc){
            System.out.println("Greska u konekciji 2");
            JOptionPane.showMessageDialog(null, "Morate ispuniti sva polja!");
        }
    }
    
    //azuriranje kupca
    public void azuriranjeKupca() throws ClassNotFoundException{
        Class.forName("com.mysql.jdbc.Driver");
        try(Connection conn=DriverManager.getConnection("jdbc:mysql://localhost/prodavnica", "root", "unesite lozinku")){
            
            Statement st=conn.createStatement();
                            
            st.execute("UPDATE `prodavnica`.`kupci` SET `kupciID`='"+idKupca+"', `imeIprezime`='"+imeIPrezimeKupca+"', `BrTelefona`='"+brTelKupca+"' WHERE `kupciID`='"+idKupca+"'");//azurirranje     
                       
            
        }catch(Exception exc){
            System.out.println("Greska u konekciji 3");
            JOptionPane.showMessageDialog(null, "Morate ispuniti sva polja!");
        }
    }
    
    
    
}

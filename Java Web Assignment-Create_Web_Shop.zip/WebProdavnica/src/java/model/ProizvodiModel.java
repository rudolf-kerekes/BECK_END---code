package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import javax.swing.JOptionPane;
import org.hibernate.validator.constraints.*;

public class ProizvodiModel {
    @NotEmpty
    private int idProizvod;
    @NotEmpty
    private String nazivProizvoda;

    public void setIdProizvod(int idProizvod) {
        this.idProizvod = idProizvod;
    }

    public void setNazivProizvoda(String nazivProizvoda) {
        this.nazivProizvoda = nazivProizvoda;
    }

    public int getIdProizvod() {
        return idProizvod;
    }

    public String getNazivProizvoda() {
        return nazivProizvoda;
    }
    
      
    
    
    //--------------------------------------------------
    //unos proizvoda
    public void unosProizvoda() throws ClassNotFoundException{
        Class.forName("com.mysql.jdbc.Driver");
        try(Connection conn=DriverManager.getConnection("jdbc:mysql://localhost/prodavnica", "root", "unesite lozinku")){
            
            Statement st=conn.createStatement();
                            
            st.execute("INSERT INTO `prodavnica`.`proizvodi` (`Naziv`) VALUES ('"+nazivProizvoda+"')");//azurirranje     
                       
            
        }catch(Exception exc){
            System.out.println("Greska u konekciji 3");
            JOptionPane.showMessageDialog(null, "Morate ispuniti sva polja!");
        }
    }
    
    //brisanje proizvoda
    public void brisanjeProizvoda() throws ClassNotFoundException{
        Class.forName("com.mysql.jdbc.Driver");
        try(Connection conn=DriverManager.getConnection("jdbc:mysql://localhost/prodavnica", "root", "unesite lozinku")){
            
            Statement st=conn.createStatement();
                            
            st.execute("DELETE FROM `prodavnica`.`proizvodi` WHERE `proizvodID`='"+idProizvod+"'");//brisanje     
                       
            
        }catch(Exception exc){
            System.out.println("Greska u konekciji 3");
            JOptionPane.showMessageDialog(null, "Morate ispuniti sva polja!");
        }
    }
    
    //azuriranje proizvoda
     public void azuriranjeProizvoda() throws ClassNotFoundException{
        Class.forName("com.mysql.jdbc.Driver");
        try(Connection conn=DriverManager.getConnection("jdbc:mysql://localhost/prodavnica", "root", "unesite lozinku")){
            
            Statement st=conn.createStatement();
                            
            st.execute("UPDATE `prodavnica`.`proizvodi` SET `Naziv`='"+nazivProizvoda+"' WHERE `proizvodID`='"+idProizvod+"'");//brisanje     
                       
            
        }catch(Exception exc){
            System.out.println("Greska u konekciji 3");
            JOptionPane.showMessageDialog(null, "Morate ispuniti sva polja!");
        }
    }
}

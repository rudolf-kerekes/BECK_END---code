package kontroler;

import javax.validation.Valid;

import model.KupciModel;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import javax.validation.constraints.*;

@Controller
public class KontolerKupac {
    @RequestMapping(value="/Kupci", method = RequestMethod.GET)
    public String kreirajFormu(ModelMap model){
        model.addAttribute("kupac", new KupciModel());
        
        return "Kupci";
    }
    
    @RequestMapping(value="/Kupci", method = RequestMethod.POST)
    public String dodajKupca(@ModelAttribute("kupac") @Valid KupciModel kupac,BindingResult rez, ModelMap model) throws ClassNotFoundException{
        
        if(rez.hasErrors()){
            return "Kupci";
        }
        
        kupac.unosKupaca();
        kupac.brisanjeKupca();
        kupac.azuriranjeKupca();
        
        kreirajFormu(model);
        
        return "Kupci";
    }

    
}

package kontroler;

import javax.validation.Valid;
import model.KupciModel;
import model.ProdajaModel;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import javax.validation.constraints.*;
import org.hibernate.validator.constraints.*;
@Controller
public class ProdajaKontroler {
    ProdajaModel pr=new ProdajaModel();
    @RequestMapping(value = "/ProdajaProizvoda", method = RequestMethod.GET)
    public String kreirajProdaju(ModelMap model) throws ClassNotFoundException{
        model.addAttribute("prodajap", new ProdajaModel());
        
        
        return "ProdajaProizvoda";
    }
    
    @RequestMapping(value="/ProdajaProizvoda", method = RequestMethod.POST)
    public String prodajProi(@ModelAttribute("prodajap") @Valid ProdajaModel prodaja,BindingResult rez, ModelMap model) throws ClassNotFoundException{
       if(rez.hasErrors()){
           return "ProdajaProizvoda";
       }
        
        prodaja.prodajaProizvoda();
        //prodaja.spisakKupljenihProizvoda();
        
        kreirajProdaju(model);
        return "ProdajaProizvoda";
    }
    
}

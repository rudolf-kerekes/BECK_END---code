package kontroler;

import javax.validation.Valid;
import model.KupciModel;
import model.ProizvodiModel;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class KontrolerProizvod {
    @RequestMapping(value="/Proizvodi", method = RequestMethod.GET)
    public String kreirajFormu2(ModelMap model){
        model.addAttribute("proizvod", new ProizvodiModel());
        
        return "Proizvodi";
    }
    
    @RequestMapping(value="/Proizvodi", method = RequestMethod.POST)
    public String dodajProizvod(@ModelAttribute("proizvod") @Valid ProizvodiModel proizvod, BindingResult rez, ModelMap model) throws ClassNotFoundException{
        if(rez.hasErrors()){
            return "Proizvodi";
        }
        
        proizvod.unosProizvoda();
        proizvod.brisanjeProizvoda();
        proizvod.azuriranjeProizvoda();
        
        kreirajFormu2(model);
        return "Proizvodi";
    }
}

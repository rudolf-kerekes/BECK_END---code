
package assignment.rukovanje_fajl_sistemom;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Scanner;

public class AssignmentRukovanje_Fajl_Sistemom {
 public static void main(String[] args) throws FileNotFoundException {
        for (int i = 0; i < 1000; i++) {
            System.out.println("\n                                  ---------------------------------------------------------------------------------------------------- ");
            System.out.println("Unesite vasu izabranu komandu:   |   list  |   info   |  create directory  |  rename  |   copy  |  move  |  delete  |  help  |  exit  | ");
            System.out.println("                                  ---------------------------------------------------------------------------------------------------- ");
            System.out.println("vas izbor je: \n------------- ");
            Scanner scaner = new Scanner(System.in);

            //  Grananje prema odabranom unosu
            switch (scaner.next().toLowerCase()) {
     //  Izlistavanje Direktorijuma
                case "list": {
                    System.out.println("Unesite direktorijum koji zelite da izlistate:");
                    File f_2 = new File(scaner.next());
                    if (f_2.exists() && f_2.isDirectory()) {
                        String[] elements = f_2.list();
                        for (String element : elements) {
                            System.out.println(element);
                        }
                    } else {
                        System.out.println("Direktorijum ne postoji, proverite da li ste uneli ispravnu putanju.");
                    }
                    break;
                }
      // Info o fajlu          
                case "info": {
                    System.out.println("Unesite putanju fajla ciji info zelite da pregledate:");
                    File f_1 = new File(scaner.next());
                    if (f_1.exists()) {
                        System.out.println("Putanja fajla: " + f_1.getAbsolutePath());
                        System.out.println("Ime fajla: " + f_1.getName());
                        System.out.println("Slobodan prostor na disku: " + f_1.getFreeSpace() / 1024 / 1024 / 1024 + "GB");
                        System.out.println("Velicina: " + f_1.length() + "B");
                        Instant instantLastModified = Instant.ofEpochMilli(f_1.lastModified());
                        LocalDateTime dateTimeLastModified = LocalDateTime.ofInstant(instantLastModified, ZoneId.systemDefault());
                        System.out.println("Datum poslednje izmene: " + dateTimeLastModified);
                    }
                    break;
                }
     // Kreiranje novog direktorijuma           
                case "create_dir": {
                    System.out.println("Unesite zeljeno ime za direktorijum:");
                    String ime = (scaner.next());
                    System.out.println("Unesite lokaciju na kojoj zelite da sacuvate direktorijum " + ime + ":");
                    String direktorijum = (scaner.next());
                    String putanja = direktorijum + "\\" + ime;

                    File f1 = new File(putanja);

                    if (!f1.exists()) {
                        f1.mkdir();
                        System.out.println("Direktorijum " + ime + " je kreiran");
                    } else {
                        System.out.println("Direktorijum " + ime + " vec postoji!");
                    }
                    break;
                }
     // Promena naziva foldera
                case "rename": {
                    System.out.println("Unesite staro ime foldera:");
                    String ime = (scaner.next());
                    System.out.println("Unesite putanju do foldera " + ime + ":");
                    String direktorijum = (scaner.next());
                    System.out.println("Unesite novo ime foldera:");
                    String novo_ime = (scaner.next());

                    String putanjaStara = direktorijum + "\\" + ime;
                    String putanjaNova = direktorijum + "\\" + novo_ime;

                    File staro_Ime = new File(putanjaStara);
                    File novo_Ime = new File(putanjaNova);

                    if (!staro_Ime.exists()) {
                        System.out.println("Folder na zadatoj lokaciji ne postoji!\nLokacija: " + staro_Ime.getAbsolutePath());
                        return;
                    } else if (novo_Ime.exists()) {
                        System.out.println("Takav folder na zadatoj lokaciji vec postoji!\nLokacija: " + novo_Ime.getAbsolutePath());
                        return;
                    } else {
                        if (staro_Ime.renameTo(novo_Ime)) {
                            System.out.println("Fajl " + ime + " je uspesno preimenovan!\nnadalje " + ime + " mozete naci pod imenom: " + novo_ime);
                        } else {
                            System.out.println("Doslo je do greske.\nNije moguce preimenovati fajl: " + ime);
                        }
                    }
                    break;
                }
     // Kopiranje  fajla       
                case "copy": {
                    System.out.println("Unesite ime fajla koji zelite da kopirate sa ekstenzijom:");
                    File imeFajla = new File(scaner.next());
                    System.out.println("Unesite lokaciju fajla " + imeFajla + ":");
                    File staraLok = new File(scaner.next() + "\\" + imeFajla);
                    System.out.println("Unesite novo ime fajla: " + imeFajla);
                    String imeIskopiranogFajla = scaner.next();
                    System.out.println("Unesite memorijsku lokaciju gde ce fajl " + imeIskopiranogFajla + " biti iskopiran:");
                    File novaLok = new File(scaner.next() + "\\" + imeIskopiranogFajla);

                    try {
                        FileInputStream inputStream = new FileInputStream(staraLok);
                        FileOutputStream outputStream = new FileOutputStream(novaLok);

                        byte[] buffer = new byte[1024];
                        int length;
                        while ((length = inputStream.read(buffer)) > 0) {
                            outputStream.write(buffer, 0, length);
                        }
                        System.out.println("Fajl je " + imeIskopiranogFajla + " je uspesno iskopiran!");
                    } catch (IOException exc) {
                        System.out.println(exc);
                    }
                    break;
                }
     // Premestanje fajla           
                case "move": {
                    try {
                        System.out.println("Unesite staru lokaciju fajla:");
                        File staraLok = new File(scaner.next());
                        System.out.println("Unesite memorijsku lokaciju gde zelite da premestite fajl:");
                        File novaLok = new File(scaner.next());

                        if (staraLok.renameTo(new File(novaLok + "\\" + staraLok.getName()))) {
                            System.out.println("Fajl " + staraLok.getName() + " je uspesno premesten!");
                        } else {
                            System.out.println("Doslo je do greske!\nFajl " + staraLok.getName() + " nije premesten!");
                        }

                    } catch (Exception exc) {
                        System.out.println(exc);
                    }
                    break;
                }
     // Brisanje fajla           
                case "delete": {
                    System.out.println("Unesite ime fajla, istom navedite ekstenziju:");
                    String ime = (scaner.next());
                    System.out.println("Unesite putanju do fajla:");
                    String direktorijum = (scaner.next());
                    String putanja = direktorijum + "\\" + ime;

                    File f1 = new File(putanja);
                    
                    System.out.println("Da li ste sigurni da zelite da obrisete fajl " + ime + " na lokaciji: " + putanja + "\nOpcije: yes, no");
                    if ("yes".equals(scaner.next().toLowerCase())) {
                        if (f1.exists()) {
                            f1.delete();
                            System.out.println("Fajl " + ime + " je obrisan.");
                        } else {
                            System.out.println("Doslo je do greske.\nFajl " + ime + " nije obrisan.");
                        }
                    }
                    break;
                }
    // Informacije o mogucem odabiru komandi i njihovim aktivnostima            
                case "help": {
                    System.out.println("Komanda: list         - izlistava sve direktorijume sa odabrane lokacije.\nKomanda: info         - pruza prikaz informacija o fajlu (ime, putanja, velicina, datum kreiranja, datum poslednje izmene).\nKomanda: create_dir   - kreira direktorijum na specificnoj lokaciji.\nKomanda: rename       - dodeljuje novo ime izabranom fajlu.\nKomanda: copy         - kopira fajl sa stare na novu lokaciju.\nKomanda: move         - premesta fajl sa stare na novu lokaciju.\nKomanda: delete       - brise fajl sa specificne memorijske adrese.\nKomanda: exit         - omogucava vam da napustite program.\nKomanda: help         - prikazuje vam informacije o dosupnim komandama.\n");
                    break;
                }
     // Napustanje programa           
                case "exit": {
                     System.out.println("\nZAHVALJUJEMO STO STE KORISTILI NAS MALI PROGRAM ZA RUKOVANJE FAJL SISTEMOM");
                     System.out.println("ZELIMO VAM PRIJATAN DAN !!!");
                    System.exit(0);
                }
                default: {
                    System.out.println("Ova komanda nije prepoznatljiva file sistemu. U svakom trenutku mozete napustiti konzolu komandom 'exit'");
                }
            }
        }
    }
}
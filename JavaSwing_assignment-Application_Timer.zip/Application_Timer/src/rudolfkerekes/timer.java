
package rudolfkerekes;


/**
 *
 * @author Rudolf Kerekes
 */

import java.awt.AWTException;
import java.awt.Color;
import java.awt.Image;
import java.awt.MenuItem;
import java.awt.PopupMenu;
import java.awt.SystemTray;
import java.awt.TrayIcon;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalTime;
import java.util.Calendar;
import java.util.Date;


import javax.swing.JCheckBox;
import javax.swing.JColorChooser;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.SpinnerDateModel;
import javax.swing.SpinnerNumberModel;
import javax.swing.Timer;
import javax.swing.JFrame;
import javax.swing.JSpinner;
import javax.swing.JSlider;
import javax.swing.JButton;



public class timer {
    
    SystemTray tray;
    TrayIcon icon;
    Image img;
    
    PopupMenu trayMenu;
    MenuItem settings;
    MenuItem close;
    
    JFrame frame1;
    GridLayout grid;
    JCheckBox box1;
    JCheckBox box2;
    JButton colorB;
    JButton start;
    JButton stop;
    JSlider speed;
    JSpinner dateSpinner;
    JSpinner countSpinner;
    JLabel colorLabel;
    JLabel info;
    JDialog dialog;
    Color chosen;
    
    JFrame frame2;
    Timer timer;
    LocalTime time;
    Calendar cal;
    
    JColorChooser palette;
    
    
    public timer() {
          
    //SYSTEM TRAY
                
        tray = SystemTray.getSystemTray();
        
        try {      
            img = ImageIO.read(new File("ghost.png"));
        } 
        
        catch (IOException ex) {
            Logger.getLogger(Timer.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        icon = new TrayIcon(img);
        
        settings = new MenuItem("Settings");
        close = new MenuItem("Close");
        trayMenu = new PopupMenu();
        trayMenu.add(settings);
        trayMenu.add(close);
        icon.setPopupMenu(trayMenu);
        
        try {
            tray.add(icon);
        } catch (AWTException ex) {
            Logger.getLogger(Timer.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        dateSpinner = new JSpinner();
        dateSpinner.setModel(new SpinnerDateModel());
        dateSpinner.setEditor(new JSpinner.DateEditor(dateSpinner, "HH:mm:ss"));    
            
     // THE FRAMES 
     
        grid = new GridLayout(5, 2);
        
            frame1 = new JFrame("Application_Timer");
            frame1.setSize(400, 500);
            frame1.setLocation(200, 200);
            frame1.setResizable(false);
            frame1.setLayout(grid);              
            frame1.add(box1 = new JCheckBox("On Time: ", false));
            frame1.add(dateSpinner);
            frame1.add(box2 = new JCheckBox("Countdown (minutes): ", true));
            frame1.add(countSpinner = new JSpinner(new SpinnerNumberModel(0, 0, 10, 1)));
            frame1.add(colorB = new JButton("Set Color"));
            frame1.add(colorLabel = new JLabel());
            frame1.add(start = new JButton("Start"));
            frame1.add(stop = new JButton("Stop"));
            frame1.add(speed = new JSlider(JSlider.HORIZONTAL, 100, 3000, 1550));
            frame1.add(info = new JLabel());
        
        palette = new JColorChooser();
        colorLabel.setOpaque(true);
        
        frame2 = new JFrame("Coloresque");
        frame2.setSize(300,200);
        frame2.setLocation(600, 400);
              
    //REGISTERING ACTION LISTENERS
  
       settings.addActionListener(evt -> {          
           frame1.setVisible(true);
       });
       
       close.addActionListener(evt -> {         
            System.exit(0);       
        });
       
       colorB.addActionListener(evt -> {
           
          dialog = JColorChooser.createDialog(null,"Choose color", true, palette, new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                chosen = palette.getColor();
                colorLabel.setBackground(chosen);
                }
            }, null);
        dialog.setVisible(true);    
         });
       
       box1.addItemListener(evt -> {           
          box1.setSelected(evt.getStateChange() == evt.SELECTED ? true : false);
          box2.setSelected(evt.getStateChange() == evt.SELECTED ? false : true);
       });
       
       box2.addItemListener(evt -> {          
           box2.setSelected(evt.getStateChange() == evt.SELECTED ? true : false);
           box1.setSelected(evt.getStateChange() == evt.SELECTED ? false : true);
       });
       
       start.addActionListener(evt -> {
                      if(chosen == null) {
               info.setText("Choose a color");
                  return;}
            int l = ((int)countSpinner.getValue())*60000;
            
    //DISABLING COMPONENTS
                
           box1.setEnabled(false);       
           box2.setEnabled(false);           
           dateSpinner.setEnabled(false);          
           countSpinner.setEnabled(false);           
           speed.setEnabled(false);           
           colorB.setEnabled(false);
                     
           if(box1.isSelected()) {              
        Calendar c1 = Calendar.getInstance();
   c1.setTime((Date) dateSpinner.getValue());
 
   int h1 = c1.get(Calendar.HOUR_OF_DAY);
   int m1 = c1.get(Calendar.MINUTE);
   int s1 = c1.get(Calendar.SECOND);
             
               while(true) {                
                    Calendar c2 = Calendar.getInstance();
                      int h2 = c2.get(Calendar.HOUR_OF_DAY);
                        int m2 = c2.get(Calendar.MINUTE);
                        int s2 = c2.get(Calendar.SECOND);
                        
   String spinnerTime = Integer.toString(h1) + ":" + Integer.toString(m1) + ":" + Integer.toString(s1);
   String currentTime = Integer.toString(h2) + ":" + Integer.toString(m2) + ":" + Integer.toString(s2);
   
                   if(spinnerTime.equals(currentTime)) {
                       break;
                   }
               }
           }
                   
                   if(box2.isSelected()) {
               try {
                   Thread.sleep(l);
               } catch (InterruptedException ex) {
                   Logger.getLogger(timer.class.getName()).log(Level.SEVERE, null, ex);
               }
                   }    
                             
                   frame2.setVisible(true);
           frame2.getContentPane().setBackground(chosen);           
           timer = new Timer(speed.getValue(), e -> {
               
               if(frame2.getContentPane().getBackground() == chosen && (frame2.getContentPane().getBackground() != Color.white )) {                   
                   frame2.getContentPane().setBackground(Color.white);
                   
               } else if(chosen.equals(Color.white) && frame2.getContentPane().getBackground() != Color.black) {                   
                   frame2.getContentPane().setBackground(Color.black);
                   
               } else if(!(frame2.getContentPane().getBackground() == chosen)) {               
                   frame2.getContentPane().setBackground(chosen);
               }
           });
           timer.setRepeats(true);
           timer.start();
       });
       
       stop.addActionListener(evt -> {          
           box1.setEnabled(true);
           box2.setEnabled(true);
           dateSpinner.setEnabled(true);
           countSpinner.setEnabled(true);
           speed.setEnabled(true);
           colorB.setEnabled(true);           
           frame2.setVisible(false);
           timer.stop();
       });
               }

    public static void main(String[] args) {       
       new timer();      
    }
}

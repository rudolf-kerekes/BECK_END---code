/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package internetselling;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.Contract;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 * FXML Controller class
 *
 * @author hp
 */
public class FXMLDeleteController implements Initializable {

    Session sesija = null;
    Transaction tx = null;

    @FXML
    private Button back;

    @FXML
    private Button delete;

    @FXML
    private TextField textField;

    @FXML
    private Label label;

    @FXML
    private void handleButtonAction(ActionEvent event) throws IOException {
        Parent doc_page_parent = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
        Scene doc_page_scene = new Scene(doc_page_parent);
        Stage doc_app_stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        doc_app_stage.setScene(doc_page_scene);
        doc_app_stage.show();
    }

    @FXML
    private void handleButtonActionDelete(ActionEvent event) throws IOException {
        label.setText("");
        try {
            sesija = hibernate.HibernateUtil.getSessionFactory().openSession();
            tx = sesija.beginTransaction();
            int id = Integer.parseInt(textField.getText());
            Contract c = (Contract) sesija.get(Contract.class, id);
            sesija.delete(c);
            tx.commit();
            label.setText("Deleted sucesfully...");
            setOptions();
        } catch (NumberFormatException br) {
            label.setText("Error!!!");
            setOptions();
            br.printStackTrace();
        } catch (HibernateException ex) {
            label.setText("Error!!!");
            setOptions();
            if (tx != null) {
                tx.rollback();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
label.setText("Error!!!");
setOptions();
        } finally {
            sesija.flush();
            sesija.close();
        }

    }

     public void setOptions(){
        textField.setText(""); 
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package internetselling;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.stage.Stage;

/**
 *
 * @author hp
 */
public class FXMLDocumentController implements Initializable {
    
   @FXML
   private Button newSell;
   
    @FXML
   private Button delete;
   
   @FXML
   private Button viewSell;
   
   @FXML
   private Button deleteSell;
    
    
    @FXML
    private void handleButtonAction(ActionEvent event) throws IOException {
    Parent new_page_parent =  FXMLLoader.load(getClass().getResource("FXMLNewSell.fxml"));
    Scene new_page_scene = new Scene(new_page_parent);
    Stage new_app_stage = (Stage)((Node) event.getSource()).getScene().getWindow();
    new_app_stage.setScene(new_page_scene);
     new_app_stage.show();
    }
    
     @FXML
    private void handleButtonAction1(ActionEvent event) throws IOException {
    Parent view_page_parent =  FXMLLoader.load(getClass().getResource("FXMLView.fxml"));
    Scene view_page_scene = new Scene(view_page_parent);
    Stage view_app_stage = (Stage)((Node) event.getSource()).getScene().getWindow();
    view_app_stage.setScene(view_page_scene);
     view_app_stage.show();
    }
    
     @FXML
    private void handleButtonAction2(ActionEvent event) throws IOException {
    Parent delete_page_parent =  FXMLLoader.load(getClass().getResource("FXMLDelete.fxml"));
    Scene delete_page_scene = new Scene(delete_page_parent);
    Stage delete_app_stage = (Stage)((Node) event.getSource()).getScene().getWindow();
    delete_app_stage.setScene(delete_page_scene);
     delete_app_stage.show();
    }
    
      @FXML
    private void handleButtonActionExit(ActionEvent event) throws IOException {
  System.exit(0);
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
    }    
    
}

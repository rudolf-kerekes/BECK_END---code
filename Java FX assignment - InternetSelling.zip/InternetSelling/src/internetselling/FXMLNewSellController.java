/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package internetselling;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.stage.Stage;
import model.Contract;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 * FXML Controller class
 *
 * @author hp
 */
public class FXMLNewSellController implements Initializable {
    
    Session sesija = null;
    Transaction tx = null;
    
    @FXML
    private Button back;
    
    @FXML
    private Button save;
    
     @FXML
    private Label label;
    
    @FXML
    private TextField name;
    
    @FXML
    private TextField surname;
    
    @FXML
    private TextField address;
    
    @FXML
    private ChoiceBox flowRate;
    
    @FXML
    private ChoiceBox flow;
    
     @FXML
    private ToggleGroup duration;
     
      @FXML
    private RadioButton radio1;
      
         @FXML
    private RadioButton radio2;
      
     @FXML
    private void handleButtonAction(ActionEvent event) throws IOException {
    Parent doc_page_parent =  FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
    Scene doc_page_scene = new Scene(doc_page_parent);
    Stage doc_app_stage = (Stage)((Node) event.getSource()).getScene().getWindow();
    doc_app_stage.setScene(doc_page_scene);
     doc_app_stage.show();
    }
    
    @FXML
    public void save(ActionEvent event){
        label.setText("");
       
        if(!name.getText().isEmpty() && !surname.getText().isEmpty() && !address.getText().isEmpty()){
             Contract c = new Contract(name.getText(), surname.getText(), address.getText(), (String) flowRate.getValue(), (String) flow.getValue(), duration.getSelectedToggle().getUserData().toString());
        try {
            sesija = hibernate.HibernateUtil.getSessionFactory().openSession();
            tx = sesija.beginTransaction();
            sesija.save(c); 
            tx.commit();
            label.setText("Saved sucesfully...");
            setOptions();
        } catch (HibernateException ex) {
            if (tx != null) {
                tx.rollback();
            }
            }finally{
            sesija.flush();
            sesija.close();
        }
            
            
        } else{
            setOptions();
            label.setText("Error, try again...");
        }
    }
    
    public void setOptions(){
        name.setText("");
        surname.setText("");
        address.setText(""); 
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}

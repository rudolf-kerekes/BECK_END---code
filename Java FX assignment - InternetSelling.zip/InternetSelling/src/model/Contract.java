
package model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Contract {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String name;
    private String surname;
    private String address;
    private String flowRate;
    private String flow;
    private String contractDuration;

    public Contract() {
    }

    public Contract(String name, String surname, String address, String flowRate, String flow, String contractDuration) {
        this.name = name;
        this.surname = surname;
        this.address = address;
        this.flowRate = flowRate;
        this.flow = flow;
        this.contractDuration = contractDuration;
    }
    
    

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getFlowRate() {
        return flowRate;
    }

    public void setFlowRate(String flowRate) {
        this.flowRate = flowRate;
    }

    public String getFlow() {
        return flow;
    }

    public void setFlow(String flow) {
        this.flow = flow;
    }

    public String getContractDuration() {
        return contractDuration;
    }

    public void setContractDuration(String contractDuration) {
        this.contractDuration = contractDuration;
    }

    @Override
    public String toString() {
        return "Contract{" + "id=" + id + ", name=" + name + ", surname=" + surname + ", address=" + address + ", flowRate=" + flowRate + ", flow=" + flow + ", contractDuration=" + contractDuration + '}';
    }
       
    
}

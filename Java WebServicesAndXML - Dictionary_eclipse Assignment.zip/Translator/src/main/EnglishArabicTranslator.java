package main;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import classes.Translator;
@WebService
public class EnglishArabicTranslator{
	
	private Translator returnTranslator() throws JAXBException, IOException{
		String xml = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><translator><air>hawa</air><ard>earth</ard><earth>ard</earth><fire>nar</fire><hawa>air</hawa><maan>water</maan><nar>fire</nar><water>maan</water></translator>";
		FileWriter fw = new FileWriter("c:\\users\\public\\dictionary.xml");
		fw.write(xml);
		fw.flush();
		fw.close();
		JAXBContext jaxc = JAXBContext.newInstance("classes");
		Unmarshaller unm = jaxc.createUnmarshaller();
		Translator trn = (Translator) unm.unmarshal(new File("c:\\users\\public\\dictionary.xml"));
		return trn;
	}
	@WebMethod
	public String eng2Arab(String word) throws JAXBException, IOException{
		Translator tr = returnTranslator();
		HashMap<String, String> dictionary = new HashMap<>();
		dictionary.put("fire", tr.getFire());
		dictionary.put("air", tr.getAir());
		dictionary.put("water", tr.getWater());
		dictionary.put("earth", tr.getEarth());
		String translation = dictionary.get(word);
		if(translation == null){
			translation = "requested word is not in the dictionary";
		}
		return translation;
	}
	@WebMethod
	public String arab2Eng(String word) throws JAXBException, IOException{
		Translator tr = returnTranslator();
		HashMap<String, String> dictionary = new HashMap<>();
		dictionary.put("ard", tr.getArd());
		dictionary.put("hawa", tr.getHawa());
		dictionary.put("nar", tr.getNar());
		dictionary.put("maan", tr.getMaan());
		String translation = dictionary.get(word);
		if(translation == null){
			translation = "requested word is not in the dictionary";
		}
		return translation;
	}
}


public class Chocolate extends Product {
          
    double tezina;
    
    
        Chocolate(String ime,String barkod,double cena,double tezina){
           super(ime,barkod,cena);
           this.tezina = tezina;         
       }
        
    @Override
       public String toString(){
           return "Naziv proizvoda je: Chokolada " + this.ime + 
                   "\n Bar kod je : " + this.barkod + 
                   "\n Tezina je : " + this.tezina + " grama" +
                   "\n Cena je : " + cena() + " dinara" + "\n";
       }
}


public class Main {
  
    public static void main(String[] args)
    {
        //Instanciranje klase Wine
        Product vino = new Wine("Tokay","55551", 100, 0.7);
        System.out.println(vino);  
        
        //Instanciranje klase Chocolate
        Product chokolada = new Chocolate("Nestle","54321", 100, 100);
        System.out.println(chokolada);
    }  
}

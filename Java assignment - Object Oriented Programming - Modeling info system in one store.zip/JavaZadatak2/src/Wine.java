//Klasa Wine, nasledjuje klasu Proizvod
public class Wine extends Product
{
   
    double zapremina;
        final double pdv2 = 1.10;            // Dodatni porez
        
    public Wine(String ime, String barkod, double cena,double zapremina) {
        super(ime, barkod, cena);
        this.zapremina = zapremina;
    }
    
      
          public double cena2(){
            return cena() * this.pdv2;
}
    
 @Override
          public String toString(){
              return "Naziv proizvoda je: Vino " +this.ime +
                     "\n Bar kod je : " + this.barkod +
                     "\n Zapremina je : " + this.zapremina +
                     " Litara" + "\n Cena je : " + cena2() + " dinara" + "\n";
          }
          
}
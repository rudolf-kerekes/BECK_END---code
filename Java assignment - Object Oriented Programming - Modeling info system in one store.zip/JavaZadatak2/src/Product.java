
public abstract class Product {
           // Deklaracija promenljivih:
    public String ime;                     // ime proizvoda
    public String barkod;                 // barkod proizvoda
    public double osnovnacena;           // osnovna cena proizvoda
    final double  pdv = 1.20;                  // porez   
    
          // Deklaracija metoda
    Product(String ime,String barkod,double osnovnacena){
            this.ime = ime;
            this.barkod = barkod;
            this.osnovnacena = osnovnacena;
    }
    
         
          
       public double cena(){
           return this.osnovnacena * this.pdv;
       } 
    
      @Override
        public String toString() {
            return "Naziv proizvoda je : " + this.ime + "\n Bar kod je : " + this.barkod + "\n Cena je : " + cena() + "din";
           
        }
            
    

            
    
    
}

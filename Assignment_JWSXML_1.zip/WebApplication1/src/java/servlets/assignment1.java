/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlets;


import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;


@WebServlet(name = "assignment1", urlPatterns = {"/assignment1"})

public class assignment1 extends HttpServlet {
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            
        throws IOException, ParserConfigurationException, ServletException, SAXException {
                response.setContentType("text/html;charset=UTF-8");
                       
            try (PrintWriter out = response.getWriter()) {
                     DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
                     DocumentBuilder db = dbf.newDocumentBuilder();           
                     Document doc = db.parse(request.getParameter("path"));
                     
                        out.println("<!DOCTYPE html>");
                        out.println("<html>");
                        out.println("<head>");
                        out.println("<title>Servlet Parser</title>");
                        out.println("</head>");
                        out.println("<body>");
                        out.println("<h1> Books </h1>");
            
            NodeList nodes = doc.getElementsByTagName("book_name");
            
            for (int a = 0; a < nodes.getLength(); a++) {
                Element element = (Element) nodes.item(a);
                double price = Double.parseDouble(element.getElementsByTagName("price").item(0).getTextContent());
                String date = element.getElementsByTagName("publish_date").item(0).getTextContent();
                String title = element.getElementsByTagName("title").item(0).getTextContent();
                int year = Integer.parseInt(date.split("-")[0]);
                
                if (price > 10 && year > 2005) {
                    String id = element.getAttribute("id");
                    String author = element.getElementsByTagName("author").item(0).getTextContent();
                    String genre = element.getElementsByTagName("genre").item(0).getTextContent();
                    String description = element.getElementsByTagName("description").item(0).getTextContent();
                  
                    out.println("<h1 style='border: 2px solid blue'>" + title + "</h1>");
                    out.println("<p> Book's id is: " + id + "</p>");
                    out.println("<p> Author is: " + author + "</p>");
                    out.println("<p> Genre is: " + genre + "</p>");
                    out.println("<p>Publish date is: " + date + "</p>");
                    out.println("<p>Description: " + description + "</p>");
                    out.println("<p> Price of book is: " + price + "</p>");
                }
            }
                    out.println("</body>");
                    out.println("</html>");
            }
        }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } 
        
        catch (ParserConfigurationException ex) {
            Logger.getLogger(assignment1.class.getName()).log(Level.SEVERE, null, ex);
        } 
        
        catch (SAXException ex) {
            Logger.getLogger(assignment1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }


    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        try {
            processRequest(request, response);
        } 
        
        catch (ParserConfigurationException ex) {
            Logger.getLogger(assignment1.class.getName()).log(Level.SEVERE, null, ex);
        } 
        
        catch (SAXException ex) {
            Logger.getLogger(assignment1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }


        //@return a String containing short description of the servlet
    @Override
    public String getServletInfo() {
        return "Short description";
    }  

}